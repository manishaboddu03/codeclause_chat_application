# CodeClause_Chat_Application
![image](https://github.com/ReubenMatrix/CodeClause_Chat_Application/assets/136352370/9b14331a-d55f-4b56-8740-f9cfb5c574e2)


![image](https://github.com/ReubenMatrix/CodeClause_Chat_Application/assets/136352370/fde0c441-cc73-4543-a276-2afffdc9c4ae)


![image](https://github.com/ReubenMatrix/CodeClause_Chat_Application/assets/136352370/8e0e775d-ff88-491e-b154-0a07652284b3)

